package Week_three;

public class Q2 {


	public static void main(String[] args) {


double a=2.6;
double b=1.3;

System.out.println(a+b);
System.out.println(a-b);
System.out.println(a*b);
System.out.println(a/b);
System.out.println(a%b);

	}
}



