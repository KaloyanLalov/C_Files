package Week_three;

public class Q3 {
	public static void main(String[] args)
int n;


	;
	;
}

}