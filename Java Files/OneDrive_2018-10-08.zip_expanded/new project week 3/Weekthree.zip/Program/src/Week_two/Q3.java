package Week_two;

public class Q3 {

}
